# MultiWeb 10 (Android source project)

MultiWeb 10 is a small Android WebView launcher with up to ten profile slots. Each slot is declared in its own Android process and receives a distinct WebView data-directory suffix. This is the mechanism used to separate cookies, local storage, cache, and website login state between profiles.

## Build

1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support).
2. Install Android SDK Platform 35 and a compatible JDK (17 recommended).
3. Let Gradle sync, then choose **Build > Build APK(s)**.
4. Install the debug APK on Android 9 or newer.

## Use

1. Open MultiWeb 10.
2. Tap a profile slot, enter a profile name and website URL, then choose **Create shortcut**.
3. Accept the launcher prompt. Repeat for other slots, using the same site and different account logins if desired.
4. Open each home-screen icon separately and sign in to the intended account.

## Important limitations

- This is source code, not a precompiled/signed APK. It has not been built or tested on a physical phone in this environment.
- Ten separate WebView processes can use substantial RAM and battery. Keep only the profiles you need active.
- Some websites block embedded WebViews, require Chrome/custom tabs, or enforce device/session limits; those sites may not work.
- The Android launcher controls pinned shortcut support and may limit shortcut count.
- Profiles are separate from one another, but they are not a substitute for a secure password manager. Use HTTPS sites and never share the APK with unknown parties.
- Android WebView and system WebView provider updates may affect behavior.
