package com.multiweb10

import android.app.Activity
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private val profileClasses = arrayOf(
        Profile1Activity::class.java, Profile2Activity::class.java, Profile3Activity::class.java,
        Profile4Activity::class.java, Profile5Activity::class.java, Profile6Activity::class.java,
        Profile7Activity::class.java, Profile8Activity::class.java, Profile9Activity::class.java,
        Profile10Activity::class.java
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24) }
        root.addView(TextView(this).apply { text = "MultiWeb 10"; textSize = 26f })
        root.addView(TextView(this).apply {
            text = "Create up to 10 independent website profiles. Each profile has its own browser data and login session."
            textSize = 14f; setPadding(0, 8, 0, 18)
        })
        for (i in 0 until 10) {
            val index = i + 1
            val button = Button(this).apply {
                text = "Set up Profile $index / Add Home Screen icon"
                setOnClickListener { configureProfile(index) }
            }
            root.addView(button)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun configureProfile(number: Int) {
        val nameInput = EditText(this).apply { hint = "Profile name (e.g. Instagram 2)"; setText("Profile $number") }
        val urlInput = EditText(this).apply {
            hint = "Website URL (https://example.com)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0); addView(nameInput); addView(urlInput) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Configure Profile $number")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create shortcut") { _, _ ->
                val name = nameInput.text.toString().trim().ifBlank { "Profile $number" }
                var url = urlInput.text.toString().trim()
                if (url.isBlank()) { Toast.makeText(this, "Enter a website URL", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                val intent = Intent(this, profileClasses[number - 1]).apply {
                    action = "com.multiweb10.OPEN_PROFILE_$number"
                    putExtra("profile_name", name)
                    putExtra("profile_url", url)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val manager = getSystemService(ShortcutManager::class.java)
                    val shortcut = ShortcutInfo.Builder(this, "multiweb_profile_$number")
                        .setShortLabel(name.take(10))
                        .setLongLabel(name)
                        .setIcon(Icon.createWithResource(this, android.R.drawable.ic_menu_view))
                        .setIntent(intent)
                        .build()
                    if (manager.isRequestPinShortcutSupported) {
                        manager.requestPinShortcut(shortcut, null)
                        Toast.makeText(this, "Shortcut request sent. Check your Home Screen.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Your launcher does not support pinned shortcuts.", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this, "Android 8 or newer is required for shortcuts.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }
}
