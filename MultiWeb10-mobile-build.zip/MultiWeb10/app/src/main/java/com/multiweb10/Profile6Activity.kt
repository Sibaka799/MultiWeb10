package com.multiweb10

class Profile6Activity : ProfileActivityBase()
