package com.multiweb10

class Profile7Activity : ProfileActivityBase()
