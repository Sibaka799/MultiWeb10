package com.multiweb10

class Profile1Activity : ProfileActivityBase()
