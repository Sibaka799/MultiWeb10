package com.multiweb10

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.*
import android.widget.*

open class ProfileActivityBase : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val name = intent.getStringExtra("profile_name") ?: "Website profile"
        val url = intent.getStringExtra("profile_url") ?: "https://example.com"
        title = name
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val address = EditText(this).apply {
            setSingleLine(true); textSize = 13f; setText(url)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setSelectAllOnFocus(false)
        }
        val go = Button(this).apply { text = "Go"; setOnClickListener { loadAddress(address.text.toString()) } }
        bar.addView(address); bar.addView(go)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
        }
        web.webChromeClient = WebChromeClient()
        layout.addView(bar)
        layout.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(layout)
        web.loadUrl(url)
    }
    private fun loadAddress(raw: String) {
        var value = raw.trim()
        if (value.isEmpty()) return
        if (!value.startsWith("https://") && !value.startsWith("http://")) value = "https://$value"
        web.loadUrl(value)
    }
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        if (::web.isInitialized) { (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        super.onDestroy()
    }
}
