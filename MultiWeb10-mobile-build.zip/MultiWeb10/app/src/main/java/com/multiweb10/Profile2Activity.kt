package com.multiweb10

class Profile2Activity : ProfileActivityBase()
