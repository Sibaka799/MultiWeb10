package com.multiweb10

import android.app.Application
import android.os.Build
import android.webkit.WebView

class MultiWebApp : Application() {
    override fun attachBaseContext(base: android.content.Context?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val process = Application.getProcessName()
            val suffix = process.substringAfter(':', "main").replace(Regex("[^A-Za-z0-9_]"), "_")
            if (suffix != "main") WebView.setDataDirectorySuffix(suffix)
        }
        super.attachBaseContext(base)
    }
}
