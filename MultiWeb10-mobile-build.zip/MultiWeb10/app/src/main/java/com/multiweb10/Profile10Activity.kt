package com.multiweb10

class Profile10Activity : ProfileActivityBase()
